Updated Oct 2021

1) 6.2.1_Orthogonality_Definition_25sep2021.pptx
	- pg 6+7 (done recording)

2) 6.2.2_Orthogonal_Projections_01Oct2021.pptx
	- added pg 4 (proof) (recording NOT done)

3) 6.2.3_Orthogonal_Sets_Orthogonal_Basis_1Oct2021.pptx
	- modified pg 4, and added 5

	
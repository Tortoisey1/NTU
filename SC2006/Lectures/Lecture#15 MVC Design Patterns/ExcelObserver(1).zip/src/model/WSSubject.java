package model;

import java.util.HashSet;
import java.util.Set;

import viewcontroller.WSObserver;

/*
 * A subject interface defines subscription and notification
 * mechanism for Observer pattern.
 */

public abstract class WSSubject {
	private Set<WSObserver> views;
	
	public WSSubject() {
		views = new HashSet<WSObserver>();
	}
	
	/*
	 * A subscription method for attaching an observer object
	 * to the subject. 
	 * We essentially need a method that allows observers to
	 * express their interests in some subject. 	 
	 * Whether you name this method attach(), subscribe(), 
	 * addObserver(), register(), it does not matter. 
	 */
	protected void attach(WSObserver view) {
		views.add(view);
	}
	
	protected void detach(WSObserver view) {
		views.remove(view);
	}
	
	/*
	 * This is the simplest implementation of notification. 
	 * Observers are interested in the subject in general. We do not
	 * consider different types of changes/events in the subject
	 * in this simple illustrative example.
	 * Furthermore, we perform a simple "ALL" notification.
	 * If you need to support different types of changes/events and
	 * "selective" notification, check the lecture slide for 
	 * the solution.
	 *
	 * Note that subject does not know any specific views. It deals
	 * with only their WSObserver interface.
	 */
	protected void notifyViews() {
		for(WSObserver view : views) {
			view.update();
		}
	}
}

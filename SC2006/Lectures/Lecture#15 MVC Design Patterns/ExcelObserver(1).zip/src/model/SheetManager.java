package model;

/*
 * SheetManager is a concrete subject. 
 * In terms of MVC architecture, it is part of Model.
 * In layered architecture, it is a control object.
 * You may have other control and/or entity objects implement WSSubject.
 */

public class SheetManager extends WSSubject {
	private WorkSheet sheet;
	
	public SheetManager(WorkSheet sheet) {
		this.sheet = sheet;
	}
	
	/*
	 * This corresponds to service() operation of the Model
	 * in MVC architecture.
	 * Such service methods will update the data and then
	 * notify dependent views.
	 */
	public updateCell(Value newValue) {
		sheet.update(newValue);
		
		notify();
	}
	
	/*
	 * Simply return the whole sheet. A smart implementation can return
	 * only cells that have been changed.
	 */
	public WorkSheet getData() {
		return sheet;
	}
}

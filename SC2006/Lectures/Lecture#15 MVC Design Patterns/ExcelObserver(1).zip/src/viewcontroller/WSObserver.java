package viewcontroller;

/*
 * An observer interface defines update() method/protocol
 * for Observer pattern.
 */

public abstract class WSObserver {
	/*
	 * The simple pull update protocol. 
	 * That is, subject sends simple notification, and observer call subject.getData() to retrieve the update.
	 */
	public abstract void update();
}

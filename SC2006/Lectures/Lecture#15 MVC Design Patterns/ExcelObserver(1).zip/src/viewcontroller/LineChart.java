package viewcontroller;

import model.SheetManager;
import model.WorkSheet;

public class LineChart extends WSObserver {
	private SheetManager sheetManager;
	
	// other parts should be similar to those of EditWorksheet
	
	@Override
	public void update() {
		WorkSheet sheet = sheetManager.getData();
		
		// update line chart
	}

}

package viewcontroller;

import java.awt.event.KeyListener;

import javax.swing.JTable;

import model.SheetManager;
import model.WorkSheet;

/*
 * A concrete observer. 
 * In MVC architecture, it is a specific View of the Model.
 * In Layered architecture, it is a boundary object.
 */

public class EditWorksheet extends WSObserver {

	/*
	 * A concrete controller for handling user inputs
	 * in worksheet table view.
	 * In this specific example, we may implement this controller
	 * as a key listener attached to the table view of worksheet.
	 *
	 * According to MVC architecture, a controller needs to
	 * know of both model and view. 
	 * In this specific implementation, EditWorkSheetListener is
	 * an inner class of EditWorkSheet. It can access sheetManager attribute
	 * of EditWorksheet object.
	 * Furthermore, we implement this controller as a Java Swing
	 * Listener. Java Swing provides means to access GUI components
	 * for the listeners.
	 */
	
	private class EditWorksheetListener implements KeyListener {
		// Implements key pressed, released, typed methods
		// Just for illustration purpose
		public void keyReleased(KeyEvent event) {
			// get source cell from event and sheetTable
			
			CellValue newValue = ... // retrieve data entered in cell
			
			/*
			 * Controller in MVC belongs to UI, i.e., boundary objects.
			 * You should NOT put real application logic in MVC controllers.
			 * Instead, MVC controller should invoke methods on control objects.
			 */
			sheetManager.updateCell(newValue);
		}
	}

	/*
	 * A reference to control object (passed in by constructor)
	 */
	private SheetManager sheetManager;
	
	private JTable sheetTable;

	public EditWorksheet(SheetManager sheetManager) {
		this.sheetManager = sheetManager;
	}
	
	/*
	 * A method to create GUI components and controllers (e.g., Listeners)
	 * This can be invoked during system startup.
	 */
	public void createUI() {
		sheetTable = new JTable();
		sheetTable.addKeyListener(new EditWorksheetListener());
	}
	
	public void update() {
		WorkSheet sheet = sheetManager.getData();
		
		// update sheetTable using latest sheet
	}
}

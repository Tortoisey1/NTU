package concretecourse;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Random;

import abstraction.Course;
import abstraction.Details;

public class SE2006 extends Course implements Runnable {
	private static final String coursename = "SE2006";
	
	private Details lastAnnouncement = new Details("No New Announcement");
	
	public Details getData() {
		return lastAnnouncement;
	}
	
	//course-specific actions
	private void continuousassessment() {
		lastAnnouncement = new Details("continuousassessment: " + new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime()));
		notifyParticipants();
	}
	
	private void clickerquiz() {
		lastAnnouncement = new Details("Clicker Quiz: " + new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime()));
		notifyParticipants();
	}

	//Simulate course-specific actions
	public void run() {
		while(true) {
			Random rand = new Random();
	
		    int action = rand.nextInt((5 - 1) + 1) + 1;
			
			if(action==1) {
				clickerquiz();
			} else if(action>=2 && action<=5) {
				continuousassessment();
			}
			
			try {
				Thread.sleep(11000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public String toString() {
		return coursename;
	}
}

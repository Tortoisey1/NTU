package concretecourse;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import abstraction.Course;
import abstraction.Details;

public class SE3002 extends Course implements Runnable {
	private static final String coursename = "SE2006";

	private Details lastAnnouncement = new Details("No New Announcement");
	
	public Details getData() {
		return lastAnnouncement;
	}
	
	//course-specific actions
	private void projectupdate() {
		lastAnnouncement = new Details("Project Update: " + new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime()));
		notifyParticipants();
	}
	
	private void markingschemaupdate() {
		lastAnnouncement = new Details("Marking Schema Update: " + new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime()));
		notifyParticipants();
	}

	//Simulate course-specific actions
	public void run() {
		while(true) {
			long action = Math.round(Math.random()*100);
			
			if(action>=0 && action<=25) {
				markingschemaupdate();
			} else if(action>=26 && action<=100) {
				projectupdate();
			}
			
			try {
				Thread.sleep(7000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public String toString() {
		return coursename;
	}
}

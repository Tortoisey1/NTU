package system;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import abstraction.Course;

public class CourseList {
	private static final List<Course> courses = new ArrayList<Course>();
	
	public static void addCourse(Course course) {
		courses.add(course);
	}
	
	public static Course findInterestingCourse() {
		Random rand = new Random();

	    int index = rand.nextInt((courses.size() - 1 - 0) + 1) + 1;
	    
	    return courses.get(index - 1);
	}
}

package system;

import concretecourse.SE2006;
import concretecourse.SE3002;
import concreteparticipant.Lecturer;
import concreteparticipant.TeamLeader;
import concreteparticipant.TeamMember;

public class NTUSystem {

	public static void main(String[] args) {
		SE2006 se2006 = new SE2006();
		SE3002 se3002 = new SE3002();
		
		CourseList.addCourse(se2006);
		CourseList.addCourse(se3002);
		
		Lecturer xingzc = new Lecturer("XingZC");
		se2006.register(xingzc);
		Lecturer graham = new Lecturer("Graham");
		se2006.register(graham);

		Lecturer shenzq = new Lecturer("ShenZQ");
		se3002.register(shenzq);
		Lecturer altheia = new Lecturer("Altheia");
		se3002.register(altheia);
		
		TeamMember chunyang = new TeamMember("Chunyang");
		TeamMember gaosa = new TeamMember("GaoSa");
		TeamMember xuejiao = new TeamMember("Xuejiao");
		TeamMember lijing = new TeamMember("Lijing");
		TeamMember deheng = new TeamMember("Deheng");
		
		TeamLeader prakash = new TeamLeader("Prakash");
		TeamLeader songwen = new TeamLeader("Songwen");
		TeamLeader zehong = new TeamLeader("Zehong");
		TeamLeader donghun = new TeamLeader("Donghun");
		TeamLeader bowen = new TeamLeader("bowen");
		TeamLeader guibin = new TeamLeader("guibin");
		TeamLeader lingfeng = new TeamLeader("lingfeng");
		
		
		new Thread(se2006).start();
		new Thread(se3002).start();
		new Thread(chunyang).start();
		new Thread(gaosa).start();
		new Thread(xuejiao).start();
		new Thread(lijing).start();
		new Thread(deheng).start();
		new Thread(prakash).start();
		new Thread(songwen).start();
		new Thread(zehong).start();
		new Thread(donghun).start();
		new Thread(bowen).start();
		new Thread(guibin).start();
		new Thread(lingfeng).start();

	}

}

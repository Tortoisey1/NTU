package concreteparticipant;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import abstraction.Course;
import abstraction.Details;
import abstraction.Participant;
import system.CourseList;

public class TeamLeader extends Participant implements Runnable {

	private String name;
	
	private List<Course> registeredCourses = new ArrayList<Course>();
	
	public TeamLeader(String name) {
		this.name = name;
	}

	public void update(Course publisher) {
		Details details = publisher.getData();
		
		Random rand = new Random();

	    int action = rand.nextInt((4 - 1) + 1) + 1;

	    //Simulate team leader behavior
	    if(action == 1) {
	    	read(details);
	    } else if(action == 2) {
	    	followup(details);
	    } else if(action == 3) {
	    	prepare(details);
	    } else if(action == 4) {
	    	tellothers(details);
	    }
	}
	
	// teamleader-specific actions on update
	private void read(Details details) {
		System.out.println("LEADER " + name + " READ " + details.getMessage());
	}

	private void followup(Details details) {
		System.out.println("LEADER " + name + " FOLLOWUP " + details.getMessage());
	}

	private void prepare(Details details) {
		System.out.println("LEADER " + name + " PREPARE " + details.getMessage());
	}

	private void tellothers(Details details) {
		System.out.println("LEADER " + name + " TELLOTHERS " + details.getMessage());
	}

	public String toString() {
		return name;
	}
	
	public void run() {
		while(true) {
			Random rand = new Random();
		
		    int action = rand.nextInt((2 - 1) + 1) + 1;
		
		    // simulate register/unregister courses
		    if(action == 1) {
		    	Course course = CourseList.findInterestingCourse();
		    	if(!registeredCourses.contains(course)) {
			    	course.register(this);
			    	registeredCourses.add(course);
		    	}
		    } else if(action == 2) {
		    	if(!registeredCourses.isEmpty()) {
		    		int index = rand.nextInt((registeredCourses.size() - 1 - 0) + 1) + 1;
		    		Course course = registeredCourses.remove(index - 1);
		    		course.unregister(this);
		    	}
		    }
		    
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}

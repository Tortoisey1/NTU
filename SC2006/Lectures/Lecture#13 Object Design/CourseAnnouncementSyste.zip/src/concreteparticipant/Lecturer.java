package concreteparticipant;

import abstraction.Course;
import abstraction.Details;
import abstraction.Participant;

public class Lecturer extends Participant {
	
	private String name;
	
	public Lecturer(String name) {
		this.name = name;
	}

	public void update(Course publisher) {
		Details details = publisher.getData();
		
		read(details);
	}
	
	// Lecturer-specific action on update
	private void read(Details details) {
		System.out.println("LECTURER " + name + " READ " + details.getMessage());
	}
	
	public String toString() {
		return name;
	}
}

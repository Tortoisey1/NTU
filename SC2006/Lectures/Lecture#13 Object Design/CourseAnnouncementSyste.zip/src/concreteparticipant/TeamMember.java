package concreteparticipant;

import java.util.Random;

import abstraction.Course;
import abstraction.Details;
import abstraction.Participant;
import system.CourseList;

public class TeamMember extends Participant implements Runnable {

	private String name;
	
	public TeamMember(String name) {
		this.name = name;
	}

	public void update(Course publisher) {
		Details details = publisher.getData();
		
		Random rand = new Random();

	    int action = rand.nextInt((4 - 1) + 1) + 1;

	    //Simulate team member behavior
	    if(action == 1) {
	    	ignore(details);
	    } else if(action == 2) {
	    	smile(details);
	    } else if(action == 3) {
	    	jump(details);
	    } else if(action == 4) {
	    	dance(details);
	    }
	}
	
	// team-member-specific actions on update
	private void ignore(Details details) {
		System.out.println("MEMBER " + name + " IGNORE " + details.getMessage());
	}

	private void smile(Details details) {
		System.out.println("MEMBER " + name + " SMILE " + details.getMessage());
	}

	private void jump(Details details) {
		System.out.println("MEMBER " + name + " JUMP " + details.getMessage());
	}

	private void dance(Details details) {
		System.out.println("MEMBER " + name + " DANCE " + details.getMessage());
	}

	public String toString() {
		return name;
	}
	
	public void run() {
		while(true) {
			Random rand = new Random();
		
		    int action = rand.nextInt((2 - 1) + 1) + 1;
		
		    // simulate register/unregister courses
		    if(action == 1) {
		    	Course course = CourseList.findInterestingCourse();
		    	course.register(this);
		    } else if(action == 2) {
		    	Course course = CourseList.findInterestingCourse();
		    	course.unregister(this);
		    }
		    
			try {
				Thread.sleep(13000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}

package abstraction;

public class Details {

	private final String message;
	
	public Details(String message) {
		this.message = message;
	}
	
	public String getMessage() {
		return message;
	}
}

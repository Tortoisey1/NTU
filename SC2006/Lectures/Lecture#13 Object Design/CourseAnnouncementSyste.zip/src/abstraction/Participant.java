package abstraction;

public abstract class Participant {

	public abstract void update(Course publisher);

}

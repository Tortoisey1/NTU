package abstraction;

import java.util.HashSet;
import java.util.Set;

public abstract class Course {
	
	private final Object lock = new Object();
	
	Set<Participant> participants = new HashSet<Participant>();
	
	public void register(Participant p) {
		synchronized(lock) {
			if(participants.contains(p)) {
				System.out.println("Participants: " + p + " already register " + this);
				return;
			}
			participants.add(p);		
			System.out.println("Participants: " + p + " register " + this);
		}
	}
	
	public void unregister(Participant p) {
		synchronized(lock) {
			if(!participants.contains(p)) {
				System.out.println("Participants: " + p + " does not yet register " + this);
				return;
			}
			participants.remove(p);		
			System.out.println("Participants: " + p + " unregister " + this);
		}
	}
	
	public void notifyParticipants() {
		for(Participant p : participants) {
			p.update(this);			
		}
	}
	
	public abstract Details getData();
	
}

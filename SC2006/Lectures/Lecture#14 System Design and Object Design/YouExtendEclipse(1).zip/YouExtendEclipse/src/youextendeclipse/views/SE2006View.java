package youextendeclipse.views;


import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.part.*;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.SWT;


/**
 * I am SE2006@NTU!
 * <p>
 */

public class SE2006View extends ViewPart {

	/**
	 * The ID of the view as specified by the extension.
	 */
	public static final String ID = "youextendeclipse.views.SE2006View";

	/**
	 * The constructor.
	 */
	public SE2006View() {
		String stop = "set a breakpoint here to see who creates me";
	}

	/**
	 * This is a callback that will allow us
	 * to create the viewer and initialize it. 
	 * 
	 * This method implements the Template Method
	 * defined in the superclass. The superclass
	 * set up all settings, then call this subclass's
	 * implementation method to create the content
	 * of the subclass.
	 */
	public void createPartControl(Composite parent) {
		Label label = new Label(parent, SWT.NONE);
		Font boldFont = new Font(label.getDisplay(), new FontData("Arial", 24, SWT.BOLD));
		label.setFont(boldFont);
		label.setText("My content. I call the shots!\nI am learning SE @ NTU. I like my teacher :-)!");
	}

	/**
	 * Passing the focus request to the viewer's control.
	 */
	public void setFocus() {
	
	}
}

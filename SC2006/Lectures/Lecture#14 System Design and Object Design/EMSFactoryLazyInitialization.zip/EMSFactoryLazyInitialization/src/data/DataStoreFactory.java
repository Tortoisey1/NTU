package data;

import data.DB2Impl;
import data.DataStoreInterface;
import data.FlatFileImpl;
import data.MySQLImpl;

public class DataStoreFactory {

	// singleton for each implementation. create on the first use
	private static DataStoreInterface mysqlimpl = null;
	private static DataStoreInterface db2impl = null;
	private static DataStoreInterface flatfileimpl = null;

	
	public static DataStoreInterface getDatastore(String datastoreOption) {
		DataStoreInterface datastore = null;
		
		if(datastoreOption.equals("M")) {
			if(mysqlimpl == null) 
				mysqlimpl = new MySQLImpl();

			datastore = mysqlimpl;
		} else if(datastoreOption.equals("D")) {
			if(db2impl == null) 
				db2impl = new DB2Impl();

			datastore = db2impl;
		} else if(datastoreOption.equals("F")) {
			if(flatfileimpl == null) 
				flatfileimpl = new FlatFileImpl();

			datastore = flatfileimpl;
		} else {
			if(flatfileimpl == null) 
				flatfileimpl = new FlatFileImpl();

			datastore = flatfileimpl;
		}
		
		return datastore;
	}
	
}

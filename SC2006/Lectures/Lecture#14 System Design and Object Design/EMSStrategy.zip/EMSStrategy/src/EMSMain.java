import ui.EmergencyUI;

public class EMSMain {
	
	public static void main(String[] args) {
		
		EmergencyUI ui = new EmergencyUI();
		
		new Thread(ui).start();
		
	}
	
}

package data;

// a Singleton DataStoreFactory
public class DataStoreFactory {

	private DataStoreFactory() {
		
	}
	
	// static method to return appropriate DataStoreInterface object based on user choice
	public static DataStoreInterface getDatastore(String datastoreOption) {
		DataStoreInterface datastore = null;
		
		if(datastoreOption.equals("M")) {
			datastore = new MySQLImpl();
		} else if(datastoreOption.equals("D")) {
			datastore = new DB2Impl();
		} else if(datastoreOption.equals("F")) {
			datastore = new FlatFileImpl();
		} else {
			datastore = new FlatFileImpl();
		}
		
		return datastore;
	}
	
}

package data;

import data.DB2Impl;
import data.DataStoreInterface;
import data.FlatFileImpl;
import data.MySQLImpl;

public class DataStoreFactory {

	// create singleton for each implementation
	private static DataStoreInterface mysqlimpl = new MySQLImpl();
	private static DataStoreInterface db2impl = new DB2Impl();
	private static DataStoreInterface flatfileimpl = new FlatFileImpl();

	
	public static DataStoreInterface getDatastore(String datastoreOption) {
		DataStoreInterface datastore = null;
		
		if(datastoreOption.equals("M")) {
			datastore = mysqlimpl;
		} else if(datastoreOption.equals("D")) {
			datastore = db2impl;
		} else if(datastoreOption.equals("F")) {
			datastore = flatfileimpl;
		} else {
			datastore = flatfileimpl;
		}
		
		return datastore;
	}
	
}
